package com.ibik.pbo;

import com.ibik.pbo.applications.Login;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       new Login();
    }
}
