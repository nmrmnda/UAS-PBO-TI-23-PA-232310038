package com.ibik.pbo.applications;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.ibik.pbo.connections.Form;
import com.ibik.pbo.connections.Formdao;
import com.ibik.pbo.connections.Question;
import com.ibik.pbo.connections.Questiondao;
import com.ibik.pbo.connections.Response;
import com.ibik.pbo.connections.Responsedao;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class UserMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private int id_user;
	private int id_form=-1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		new UserMain(1);
	}

	/**
	 * Create the frame.
	 */
	public UserMain(int id) {
		id_user=id;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 414, 179);
		contentPane.add(scrollPane);
		String [] atribut= {"ID","Nama","jml_pertanyaan"};
		DefaultTableModel tableModel = new DefaultTableModel(atribut, 0);
		try {
			Formdao dao=new Formdao();
			List<Form> list=dao.findAll();
			
			for (Form form : list) {
                Object[] rowData = {
                		form.getId_form(),
                		form.getNama(),
                		form.getJml_pertanyaan()                
                };
                tableModel.addRow(rowData);
            }
		}catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Gagal memuat data: " + e.getMessage());
        }
		table = new JTable(tableModel);
		scrollPane.setViewportView(table);

		 table.addMouseListener(new MouseAdapter() {
	            @Override
	            public void mouseClicked(MouseEvent e) {
	                int selectedRow = table.getSelectedRow();
	                if (selectedRow != -1) {
	                    id_form =(int) table.getValueAt(selectedRow, 0);
	                }
	            }
	        });
		
		
		JButton isi = new JButton("Isi form");
		isi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openform();
			}
		});
		isi.setBounds(162, 212, 89, 23);
		contentPane.add(isi);
	}
	
	 private void openform() {
	        try {
	            Questiondao dao = new Questiondao();	    
	            List<Question> questions = dao.findAll(id_form);

	            if (questions.isEmpty()) {
	                JOptionPane.showMessageDialog(null, "Silahkan pilih form terlebih dahulu " );
	                return;
	            }

	            for (Question question : questions) {
	                String answer = JOptionPane.showInputDialog(question.getPertanyaan());
	                if (answer != null ) {
	                    save(answer,id_form,question.getId_question(),id_user);
	                } else {
	                    JOptionPane.showMessageDialog(null, "Jawaban tidak boleh kosong!");
	                    return;
	                }
	            }

	            JOptionPane.showMessageDialog(null, "Data berhasil disimpan!");

	        } catch (Exception ex) {
	            ex.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	        }
	    }

	    private void save(String answer , int formId , int questionId , int userId ) {
	        try {
	        	Response response=new Response();
	            Responsedao rdao=new Responsedao();
	            
	            response.setJawaban(answer);
	            response.setId_form(formId);
	            response.setId_question(questionId);
	            response.setId_user(userId);
	            rdao.savejawaban(response);
	        } catch (Exception e) {
	            e.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Gagal menyimpan jawaban: " + e.getMessage());
	        }
	    }
	} 



