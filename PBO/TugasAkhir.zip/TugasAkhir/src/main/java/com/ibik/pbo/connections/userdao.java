package com.ibik.pbo.connections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



public class userdao {
	String insert = "INSERT INTO users (nama, email, password) VALUES (?, ?, ?)";
	String find="select * from users where email = ? and password= ?";
	String forget="select password from users where email= ?";

	
	public void insertdata(user users) throws Exception{
		Connection c=new ConnectionDB().connect();
		
		PreparedStatement in=c.prepareStatement(insert);
		
		in.setString(1, users.getNama());
		in.setString(2, users.getEmail());
		in.setString(3, users.getPassword());
		
		in.executeUpdate();
		c.close();
	}
	
	public String finduser ( String email,String password) throws Exception{

		Connection c= new ConnectionDB().connect();
		PreparedStatement finder=c.prepareStatement(find);
		
		
		finder.setString(1, email);
		finder.setString(2, password);
		ResultSet rs=finder.executeQuery();
		if (rs.next()) { 
	        return rs.getString("nama");
	    } else {
	        return null; 
	    }
	}
	
	public int findid ( String email,String password) throws Exception{

		Connection c= new ConnectionDB().connect();
		PreparedStatement finder=c.prepareStatement(find);
		
		
		finder.setString(1, email);
		finder.setString(2, password);
		ResultSet rs=finder.executeQuery();
		if (rs.next()) {  
	        return rs.getInt("id_user");
	    } else {
	        return 1; 
	    }
	}
	
	public String forgetpassword(String email)throws Exception{
		Connection c=new ConnectionDB().connect();
		PreparedStatement find=c.prepareStatement(forget);
		
		find.setString(1, email);
		
		ResultSet rs=find.executeQuery();
		if (rs.next()) { 
	        return rs.getString("password");
	    } else {
	        return null; 
	    }
	}

}
