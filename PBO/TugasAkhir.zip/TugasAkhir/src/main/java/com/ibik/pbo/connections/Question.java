package com.ibik.pbo.connections;

public class Question {
	int id_question;
	String pertanyaan;
	int id_form;
	
	public int getId_question() {
		return id_question;
	}
	public void setId_question(int id_question) {
		this.id_question = id_question;
	}
	public String getPertanyaan() {
		return pertanyaan;
	}
	public void setPertanyaan(String pertanyaan) {
		this.pertanyaan = pertanyaan;
	}
	public int getId_form() {
		return id_form;
	}
	public void setId_form(int id_form) {
		this.id_form = id_form;
	}

}
