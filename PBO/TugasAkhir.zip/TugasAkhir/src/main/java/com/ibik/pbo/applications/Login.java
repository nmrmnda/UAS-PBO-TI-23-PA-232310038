package com.ibik.pbo.applications;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.ibik.pbo.connections.Admindao;
import com.ibik.pbo.connections.userdao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField emailt;
	private JPasswordField passwordt;
	private JButton Login;
	private JButton Register;
	private JLabel Forget;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("Login Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Email");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel.setBounds(33, 24, 60, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPassword.setBounds(33, 79, 129, 31);
		contentPane.add(lblPassword);
		
		emailt = new JTextField();
		emailt.setBounds(132, 24, 216, 36);
		contentPane.add(emailt);
		emailt.setColumns(10);
		
		passwordt = new JPasswordField();
		passwordt.setBounds(132, 79, 216, 36);
		contentPane.add(passwordt);
		
		Login = new JButton("Login");
		Login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String emailInput = emailt.getText();
	                String passwordInput = new String(passwordt.getPassword());
	                
	                if (emailInput.isEmpty() || passwordInput.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Silahkan isi data dengan benar");
	                } else {
	                    try {
	              
	                        userdao udao = new userdao();
	                        String nama = udao.finduser(emailInput, passwordInput);
	                      
	                        Admindao adao = new Admindao();
	                        String admin = adao.finduser(emailInput, passwordInput);
	                       
	                        
	                        
	                        if (nama!=null) {
	                            JOptionPane.showMessageDialog(null, "Selamat datang "+nama);
	                            int id_user=udao.findid(emailInput, passwordInput);
	                            new UserMain(id_user);
	                            dispose(); 
	                        }else if(admin!=null) {
	                        	  JOptionPane.showMessageDialog(null, "Selamat datang "+admin);
	                        	  int id_admin=adao.findid(emailInput, passwordInput);
		                            new MainApp(id_admin);
		                            dispose();
	                        }
	                        else {
	                            JOptionPane.showMessageDialog(null, "Data yang anda input salah");
	                        }
	                    } catch (Exception ex) {
	                        JOptionPane.showMessageDialog(null, ex.getMessage());
	                    }
	                    
	                  
	                }
	            }
				
			
		});
		Login.setBounds(236, 169, 112, 36);
		contentPane.add(Login);
		
		Register = new JButton("Register");
		Register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Register();
				dispose();
			}
		});
		Register.setBounds(87, 169, 112, 36);
		contentPane.add(Register);
		
		Forget = new JLabel("Forget Password?");
		Forget.setForeground(new Color(0, 0, 160));
		Forget.setBackground(new Color(255, 255, 255));
		Forget.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String search=JOptionPane.showInputDialog("Masukan email anda");
				try {
					userdao dao=new userdao();
					String pass=dao.forgetpassword(search);
					JOptionPane.showMessageDialog(null, "Your password is "+pass);
				}catch(Exception ap) {
					JOptionPane.showMessageDialog(null, ap.getMessage());
				}
			}
		});
		Forget.setFont(new Font("Tahoma", Font.PLAIN, 13));
		Forget.setBounds(132, 130, 172, 28);
		contentPane.add(Forget);
	}

}
