package com.ibik.pbo.connections;

public class Form {
	int id_form;
	String nama;
	int jml_pertanyaan;
	int id_admin;
	public int getId_form() {
		return id_form;
	}
	public void setId_form(int id_form) {
		this.id_form = id_form;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public int getJml_pertanyaan() {
		return jml_pertanyaan;
	}
	public void setJml_pertanyaan(int jml_pertanyaan) {
		this.jml_pertanyaan = jml_pertanyaan;
	}
	public int getId_admin() {
		return id_admin;
	}
	public void setId_admin(int id_admin) {
		this.id_admin = id_admin;
	}
	

}
