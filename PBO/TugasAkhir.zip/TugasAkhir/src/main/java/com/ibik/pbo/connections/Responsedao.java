package com.ibik.pbo.connections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Responsedao {
	String insert = "INSERT INTO response (jawaban, id_form, id_question, id_user) VALUES (?, ?, ?, ?)";
	String show = "SELECT users.nama, question.pertanyaan, response.jawaban " +
            "FROM response " +
            "JOIN question ON response.id_question = question.id_question " +
            "JOIN users ON response.id_user = users.id_user " +
            "WHERE response.id_form = ?";


	public void savejawaban(Response response) throws SQLException{
		Connection c=new ConnectionDB().connect();
		PreparedStatement in=c.prepareStatement(insert);
		
		in.setString(1, response.getJawaban());
		in.setInt(2,response.getId_form());
		in.setInt(3,response.getId_question());
		in.setInt(4,response.getId_user());
		
		in.executeUpdate();
		c.close();
	}
	
	public List<String[]> findAll(int id) throws SQLException {
	    List<String[]> hasil = new ArrayList<>();
	    Connection c = new ConnectionDB().connect();
	    PreparedStatement cari = c.prepareStatement(show);
	    cari.setInt(1, id);
	    ResultSet rs = cari.executeQuery();

	    while (rs.next()) {
            String nama = rs.getString("nama");
            String pertanyaan = rs.getString("pertanyaan");
            String jawaban = rs.getString("jawaban");
            hasil.add(new String[]{nama, pertanyaan, jawaban});
        }
	    c.close();
	    return hasil;
	}

}
