package com.ibik.pbo.applications;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.ibik.pbo.connections.user;
import com.ibik.pbo.connections.userdao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Register extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField namat;
	private JTextField emailt;
	private JPasswordField passwordt;
	private JPasswordField repasswordt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setTitle("Register Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 446, 301);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nama");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel.setBounds(33, 27, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblEmail.setBounds(33, 69, 46, 14);
		contentPane.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblPassword.setBounds(33, 109, 81, 14);
		contentPane.add(lblPassword);
		
		JLabel lblRepassword = new JLabel("Re-Password");
		lblRepassword.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblRepassword.setBounds(33, 149, 104, 14);
		contentPane.add(lblRepassword);
		
		namat = new JTextField();
		namat.setBounds(146, 23, 227, 29);
		contentPane.add(namat);
		namat.setColumns(10);
		
		emailt = new JTextField();
		emailt.setColumns(10);
		emailt.setBounds(146, 65, 227, 29);
		contentPane.add(emailt);
		
		passwordt = new JPasswordField();
		passwordt.setBounds(146, 105, 227, 29);
		contentPane.add(passwordt);
		
		repasswordt = new JPasswordField();
		repasswordt.setBounds(147, 145, 227, 29);
		contentPane.add(repasswordt);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nama = namat.getText();
                String email = emailt.getText();
                String password = new String(passwordt.getPassword());
                String rePassword = new String(repasswordt.getPassword());

                if (nama.isEmpty() || email.isEmpty() || password.isEmpty() || rePassword.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Semua field harus diisi!");
                } else if (!password.equals(rePassword)) {
                    JOptionPane.showMessageDialog(null, "Password tidak cocok!");
                } else {
                    try {
                       
                        userdao indao = new userdao();
                        user users = new user();

                        users.setNama(nama);
                        users.setEmail(email);
                        users.setPassword(password);

                        indao.insertdata(users);
                        JOptionPane.showMessageDialog(null, "Registrasi berhasil!");

                       
                        dispose();
                        new Login(); 
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + ex.getMessage());
                    }
                }
            }
        });
		btnNewButton.setBounds(262, 209, 111, 29);
		contentPane.add(btnNewButton);
	}
}
