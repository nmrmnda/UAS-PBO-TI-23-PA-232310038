package com.ibik.pbo.connections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Questiondao {
	String insert="insert into question(pertanyaan,id_form) values(?,?)";
	String show="select * from question where id_form=?";
	
	public void insert(Question question)throws SQLException{
		Connection c=new ConnectionDB().connect();
		PreparedStatement in=c.prepareStatement(insert);
		
		in.setString(1, question.getPertanyaan());
		in.setInt(2,question.getId_form());
		
		in.executeUpdate();
		c.close();
	}
	
	public String show(int id)throws SQLException{
		Connection c=new ConnectionDB().connect();
		PreparedStatement ps=c.prepareStatement(show);
		ps.setInt(1, id);
		    ResultSet rs=ps.executeQuery();
		    rs.next();
		    String question=rs.getString("pertanyaan");
		    c.close();
		    return question;
		   
	}
	public List<Question> findAll(int id_form) throws Exception {
	    List<Question> hasil = new ArrayList<>();
	    Connection c = new ConnectionDB().connect();
	    PreparedStatement cari = c.prepareStatement(show);
	    cari.setInt(1, id_form);
	    ResultSet rs = cari.executeQuery();

	    while (rs.next()) {
	        hasil.add(konversiResultSet(rs));
	    }

	    c.close();
	    return hasil;
	}

	
	private Question konversiResultSet(ResultSet rs) throws SQLException {
	    Question question = new Question();
	    question.setPertanyaan(rs.getString("pertanyaan"));
	    question.setId_question(rs.getInt("id_question"));
	    return question;
	}
}
