package com.ibik.pbo.connections;

public class Response {
	 int id_response;
	 String jawaban;
	 int id_form;
	 int id_question;
	 int id_user;
	public int getId_response() {
		return id_response;
	}
	public void setId_response(int id_response) {
		this.id_response = id_response;
	}
	public String getJawaban() {
		return jawaban;
	}
	public void setJawaban(String jawaban) {
		this.jawaban = jawaban;
	}
	public int getId_form() {
		return id_form;
	}
	public void setId_form(int id_form) {
		this.id_form = id_form;
	}
	public int getId_question() {
		return id_question;
	}
	public void setId_question(int id_question) {
		this.id_question = id_question;
	}
	public int getId_user() {
		return id_user;
	}
	public void setId_user(int id_user) {
		this.id_user = id_user;
	}
	 
	 
}
