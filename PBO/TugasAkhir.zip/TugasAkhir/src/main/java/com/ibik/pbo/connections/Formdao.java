package com.ibik.pbo.connections;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class Formdao {
	String insert="insert into form(nama,jml_pertanyaan)values (?,?)";
	String show="select * from form";
	String delete="delete * from form where id=?";
	String find="select id_form from form where nama=?";
	String getjml="select jml_pertanyaan from form where id_form=?";
	
	public void insert(Form form)throws SQLException{
		Connection c=new ConnectionDB().connect();
		
		PreparedStatement in=c.prepareStatement(insert);
		in.setString(1, form.getNama());
		in.setInt(2, form.getJml_pertanyaan());
		
		in.executeUpdate();
		c.close();
	}
	public void removed(Integer id) throws Exception {
	    if (id == null) {
	        return;
	    }
	    
	    Connection c = new ConnectionDB().connect();
	    PreparedStatement hapus = c.prepareStatement(delete);
	    hapus.setInt(1, id);
	    
	    hapus.executeUpdate();
	    
	    c.close();
	}
	
	public int getid(String nama) throws SQLException {
	    Connection c = new ConnectionDB().connect();
	    PreparedStatement ps = c.prepareStatement(find);
	    ps.setString(1, nama);
	    ResultSet rs=ps.executeQuery();
	    rs.next();
	    int id=rs.getInt("id_form");
	    c.close();
	    return id;
	   
	}

	public List<Form> findAll() throws Exception {
	    List<Form> hasil = new ArrayList<>();
	    Connection c = new ConnectionDB().connect();
	    PreparedStatement cari = c.prepareStatement(show);
	    ResultSet rs = cari.executeQuery();

	    while (rs.next()) {
	        hasil.add(konversiResultSet(rs));
	    }

	    c.close();
	    return hasil;
	}

	private Form konversiResultSet(ResultSet rs) throws SQLException {
	    Form form = new Form();
	    form.setId_form(rs.getInt("id_form"));
	    form.setNama(rs.getString("nama"));
	    form.setJml_pertanyaan(rs.getInt("jml_pertanyaan"));
	    return form;
	}
	
	public int getjml(int id) throws SQLException {
	    Connection c = new ConnectionDB().connect();
	    PreparedStatement ps = c.prepareStatement(getjml);
	    ps.setInt(1, id);
	    ResultSet rs=ps.executeQuery();
	    rs.next();
	    int jml=rs.getInt("jml_pertanyaan");
	    c.close();
	    return jml;
	   
	}
}
