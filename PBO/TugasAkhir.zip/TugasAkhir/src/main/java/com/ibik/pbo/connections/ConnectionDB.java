package com.ibik.pbo.connections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB {
	Connection con;
	public static Connection connect() throws SQLException{
		String host="localhost:3306";
		String dbname="pboapp";
		String user="root";
		String password="";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		Connection con=DriverManager.getConnection("jdbc:mysql://"+host+"/"+dbname,user,password);
		return con;
	}
	
	public Connection close() throws SQLException{
		con.close();
		return con;
	}
}
