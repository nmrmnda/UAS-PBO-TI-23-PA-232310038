package com.ibik.pbo.applications;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.ibik.pbo.connections.Form;
import com.ibik.pbo.connections.Formdao;
import com.ibik.pbo.connections.Responsedao;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;

public class ListJawaban extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private int id_form;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListJawaban frame = new ListJawaban(5);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListJawaban(int id) {
		id_form=id;
		setBounds(100, 100, 450, 300);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 414, 239);
		contentPane.add(scrollPane);
		
		String [] atribut= {"Nama","pertanyaan","jawaban"};
		DefaultTableModel tableModel = new DefaultTableModel(atribut, 0);
		try {
			Responsedao dao=new Responsedao();
			List<String[]> list=dao.findAll(id_form);
			
			for ( String[] rowData: list) {
				tableModel.addRow(rowData);
                };
                
            
		}catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Gagal memuat data: " + e.getMessage());
        }
		table = new JTable(tableModel);
		scrollPane.setViewportView(table);
	}
}
