package com.ibik.pbo.applications;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.ibik.pbo.connections.Form;
import com.ibik.pbo.connections.Formdao;
import com.ibik.pbo.connections.Question;
import com.ibik.pbo.connections.Questiondao;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

public class MainApp extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField judult;
	private JTextField jmlt;
	private JTable table;
	private DefaultTableModel tableModel;
	private int id_admin;
	private int id_form=-1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
	}

	/**
	 * Create the frame.
	 */
	public MainApp(int id) {
		id_admin=id;
		setTitle("FormApp");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 333);
		setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		judult = new JTextField();
		judult.setBounds(10, 52, 170, 20);
		contentPane.add(judult);
		judult.setColumns(10);

		jmlt = new JTextField();
		jmlt.setBounds(10, 108, 170, 20);
		contentPane.add(jmlt);
		jmlt.setColumns(10);
		jmlt.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!Character.isDigit(c) ) {
					e.consume();
					JOptionPane.showMessageDialog(null, "Hanya angka yang diperbolehkan.", "Input Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		JLabel lblNewLabel = new JLabel("Masukan judul form");
		lblNewLabel.setBounds(10, 31, 128, 14);
		contentPane.add(lblNewLabel);

		JLabel lblMasukanJumlahPertanyaan = new JLabel("Masukan jumlah pertanyaan");
		lblMasukanJumlahPertanyaan.setBounds(10, 83, 170, 14);
		contentPane.add(lblMasukanJumlahPertanyaan);

		JButton add = new JButton("Add New Form");
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addform();
			}
		});
		
		add.setBounds(10, 139, 128, 33);
		contentPane.add(add);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(227, 35, 221, 197);
		contentPane.add(scrollPane);

		String [] atribut= {"ID","Nama","jml_pertanyaan"};
		tableModel = new DefaultTableModel(atribut, 0);
		try {
			Formdao dao=new Formdao();
			List<Form> list=dao.findAll();
			
			for (Form form : list) {
                Object[] rowData = {
                		form.getId_form(),
                		form.getNama(),
                		form.getJml_pertanyaan()                
                };
                tableModel.addRow(rowData);
            }
		}catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Gagal memuat data: " + e.getMessage());
        }
		table = new JTable(tableModel);
		scrollPane.setViewportView(table);
		
		 table.addMouseListener(new MouseAdapter() {
	            @Override
	            public void mouseClicked(MouseEvent e) {
	                int selectedRow = table.getSelectedRow();
	                id_form =(int) table.getValueAt(selectedRow, 0);
	            }
	        });
		
		JButton open = new JButton("show response");
		open.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(id_form!=-1) {
					new ListJawaban(id_form);
				}else {
					JOptionPane.showMessageDialog(null, "silahkan pilih form yang ingin dibuka");
				}
				}

		});
		open.setBounds(10, 227, 128, 33);
		contentPane.add(open);
		
		JButton Regisadmin = new JButton("Add new admin");
		Regisadmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RegisterAdmin();
			}
		});
		Regisadmin.setBounds(10, 183, 128, 33);
		contentPane.add(Regisadmin);

	}

	private void addform() {
	    String nama = judult.getText();
	    String jml = jmlt.getText();

	    if (nama.isEmpty() || jml.isEmpty()) {
	        JOptionPane.showMessageDialog(null, "Silakan isi semua data.");
	    } else {
	        try {
	            int jumlah = Integer.parseInt(jml);
	            Formdao dao = new Formdao();
	            Form form = new Form();
	            form.setNama(nama);
	            form.setJml_pertanyaan(jumlah);

	            dao.insert(form);

	            int idForm = dao.getid(nama);
	            

	            
	            addquestion(idForm);

	            JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan.");
	        } catch (Exception ex) {
	            JOptionPane.showMessageDialog(null, ex.getMessage());
	        }
	    }
	}

	
	



	private void addquestion(int id) {
		try {
			int jml=Integer.parseInt(jmlt.getText());
			Questiondao dao=new Questiondao();
			Question question=new Question();
			
			for(int i = 1; i <= jml; i++) {
				String q=JOptionPane.showInputDialog("Masukan pertanyaan ke "+i);
				if (q.isEmpty()) {
	                JOptionPane.showMessageDialog(null, "Pertanyaan tidak boleh kosong. Proses dihentikan.", "Input Error", JOptionPane.ERROR_MESSAGE);
	                return;
	            }
				question.setPertanyaan(q);
	            question.setId_form(id);

	            dao.insert(question);
				
			}
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(null, ex.getMessage());
		}
		
	}
	


	   
}
